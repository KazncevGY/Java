package unitTest;

public class AnnotationException extends Exception {
	public String message;
	public AnnotationException(String m)
	{
		message=m;
	}
}
