package unitTest;

public class Checker {
	public static void isEqual(Object o1, Object o2) throws WrongResultException
	{
		if(!o1.equals(o2))
		{
			throw new WrongResultException("Checked objects was not equal.\n");
		}
	}
	
	public static void isNotEqual(Object o1, Object o2) throws WrongResultException
	{
		if(o1.equals(o2))
		{
			throw new WrongResultException("Checked objects was equal.\n");
		}
	}
	
	public static void isLess(Comparable c1, Comparable c2) throws WrongResultException
	{
		if(c1.compareTo(c2)<0)
		{
			throw new WrongResultException("First checked objects was not less than second.\n");
		}
	}
}
