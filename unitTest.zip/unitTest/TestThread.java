package unitTest;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

public class TestThread extends Thread
{
	public TestThread(Class tc, StringBuffer r)
	{
		testClass=tc;
		report=r;
		
	}
	
	public TestThread()
	{
	}

	@Override
	public void run()
	{
		StringBuilder message=new StringBuilder();
		Boolean testExist=false;
		try {
			Object testObject=testClass.newInstance();
			Method[] methods=testClass.getMethods();
			Method before=null;
			Method after=null;
			for(Method method : methods)
			{
				if(method.isAnnotationPresent(Before.class))
					if(before==null)
						before=method;
					else 
						throw new AnnotationException("More than one Before Method defined in class "+testClass.getName()+"\n");
				
				if(method.isAnnotationPresent(After.class))
					if(after==null)
						after=method;
					else 
						throw new AnnotationException("More than one After Method defined in class "+testClass.getName()+"\n");
			}
			
			 
			message.append("Class "+testClass.getName()+":\n");
			for(Method method : methods)
			{
				if(method.isAnnotationPresent(Test.class))
				{
					testExist=true;
					
					try {
						if(before!=null)
							before.invoke(testObject, null);
						} 
					catch (IllegalArgumentException | InvocationTargetException e) {
							throw new AnnotationException("Before method cannot be invoked.\n"+e.getMessage()+"\n");
						}
					try {
							method.invoke(testObject, null);
							if(!method.isAnnotationPresent(ExpectedException.class))
							{
								message.append("Test " + method.getName()+" was passed.");
							}
							else
							{
								message.append("Test " + method.getName()+" was not passed. Exception expected.\n");
							}
						}
					catch (IllegalArgumentException e) {
						message.append("Test " + method.getName()+" was not passed. Test method should not have arguments;");
					}
					catch (InvocationTargetException e){
						if(method.isAnnotationPresent(ExpectedException.class))
						{
							ExpectedException ee = method.getAnnotation(ExpectedException.class);
							if(ee.exceptionType().equals(e.getCause().getClass()))
							{
								message.append("Test " + method.getName()+" was passed. Expected Exception was caught. \n");
							}
							else
							{
								message.append("Test " + method.getName()+" was not passed. Unexpected Exception was caught.\n"+e.getCause().getMessage()+"\n");
							}
					
						}
						else if(e.getCause().getClass().equals(WrongResultException.class))
						{
							message.append("Test " + method.getName()+" was not passed." + ((WrongResultException)e.getCause()).message);
						}
						
						
					}
					try {
						if(after!=null)
							after.invoke(testObject, null);
						} 
					catch (IllegalArgumentException | InvocationTargetException e) {
							throw new AnnotationException("After method cannot be invoked.\n"+e.getMessage()+"\n");
						}
					}
					
				}

			} catch (InstantiationException | IllegalAccessException e) {
				message.append("Object of class "+testClass.getName()+"cannot be created\n" );
				message.append(e.getMessage()+"\n");
			} catch (AnnotationException e) {
				message.append(e.message);
			}
		if(!testExist)
			message.append("There are no tests in class.");
		report.append(message.toString());
	}
	Class testClass;
	StringBuffer report;
}
