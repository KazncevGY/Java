package unitTest;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.Stack;

public class Main {

	public static void main(String[] args) 
	{
		
		Integer threadsNumber=new Integer(args[0]);
		ArrayList<Class> tc=new ArrayList<Class>();
		try {
			for(int i=1; i<args.length; i++)
			tc.add(Class.forName(args[i]));
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		StringBuffer report=new StringBuffer();
		TestThread[] threads=new TestThread[threadsNumber];
		for(int i=0; i<threadsNumber && !tc.isEmpty(); i++)
		{
			threads[i]=new TestThread();
		}
		while(!tc.isEmpty())
		{
			for(int i=0; i<threadsNumber && !tc.isEmpty(); i++)
			{
				if(!threads[i].isAlive())
				{
					threads[i]=new TestThread(tc.get(0), report);
					tc.remove(0);
					threads[i].start();
				}
			}
		}
		Boolean allThreadsStops;
		do
		{
			allThreadsStops=true;
			for(int i=0; i<threadsNumber && !tc.isEmpty(); i++)
			{
				if(threads[i].isAlive())
				{
					allThreadsStops=false;
				}
			}
		}
		while(!allThreadsStops);
		System.console().writer().print(report.toString());
	}
}