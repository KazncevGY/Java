package unitTest;

public class WrongResultException extends Exception {
	public String message;
	public WrongResultException(String m)
	{
		message=m;
	}
}
